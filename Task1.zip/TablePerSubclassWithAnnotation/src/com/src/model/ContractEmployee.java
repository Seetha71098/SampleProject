package com.src.model;


import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="empscdb")
@PrimaryKeyJoinColumn(name="EmpId")

public class ContractEmployee extends Employee {
	private double payperhour;  
    private int contractduration;
    
	public double getPayperhour() {
		return payperhour;
	}
	public void setPayperhour(double payperhour) {
		this.payperhour = payperhour;
	}
	public int getContractduration() {
		return contractduration;
	}
	public void setContractduration(int contractduration) {
		this.contractduration = contractduration;
	}
    
}
