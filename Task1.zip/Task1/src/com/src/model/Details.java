package com.src.model;

public class Details extends Customer{

	private long mobnumber;
	private int price;
	public long getMobnumber() {
		return mobnumber;
	}
	public void setMobnumber(int mobnumber) {
		this.mobnumber = mobnumber;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
}
