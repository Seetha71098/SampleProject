package com.src.model;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="ecdb")
@AttributeOverrides({
	
	@AttributeOverride(name="EmpId",column=@Column(name="empid")),
	@AttributeOverride(name="name",column=@Column(name="empname")),
	@AttributeOverride(name="age",column=@Column(name="empage"))
	
	
	
})
public class ContractEmployee extends Employee {
    private int contractduration;
	private double payperhour;  

	public double getPayperhour() {
		return payperhour;
	}
	public void setPayperhour(double payperhour) {
		this.payperhour = payperhour;
	}
	public int getContractduration() {
		return contractduration;
	}
	public void setContractduration(int contractduration) {
		this.contractduration = contractduration;
	}
    
}
