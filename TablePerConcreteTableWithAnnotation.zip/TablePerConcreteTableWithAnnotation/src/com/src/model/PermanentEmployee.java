package com.src.model;


import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="epdb")
@AttributeOverrides({
	
	@AttributeOverride(name="Id",column=@Column(name="empid")),
	@AttributeOverride(name="name",column=@Column(name="empname")),
	@AttributeOverride(name="age",column=@Column(name="empage"))
	
	
	
})
public class PermanentEmployee  extends Employee{

	private double salary;
	private double bonus;
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public double getBonus() {
		return bonus;
	}
	public void setBonus(double bonus) {
		this.bonus = bonus;
	}
	
}
