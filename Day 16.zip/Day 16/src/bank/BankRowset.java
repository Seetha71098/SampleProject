package bank;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.rowset.JdbcRowSet;
import javax.sql.rowset.RowSetProvider;
import javax.sql.rowset.*;
public class BankRowset {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
			Class.forName("com.mysql.cj.jdbc.Driver");
		JdbcRowSet rs=RowSetProvider.newFactory().createJdbcRowSet();
	 String url="jdbc:mysql://localhost:3306/seethadb";
	 String username="seetha";
	 String password="seetharamesh";

	 rs.setUrl(url);
	 rs.setUsername(username);
	 rs.setPassword(password);
	 ResultSet rr;
	 System.out.println("----full table----");
	 rs.setCommand("select *  from bank");
	 rs.execute();
	 while(rs.next())
	 {
		 System.out.println(rs.getLong(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+" "+rs.getDouble(7));
	 }
	 System.out.println("-----update table----");
	  rs.absolute(3);
	     rs.updateString("amount", "400000");
	     rs.updateRow();
	     rs.setCommand("select *  from bank");
		 rs.execute();
		 while(rs.next())
		 {
			 System.out.println(rs.getLong(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+" "+rs.getDouble(7));
		 }
	     System.out.println("3 Row amount  Updated");
	 System.out.println("----insert table-------");
	 rs.moveToInsertRow();
	 rs.updateLong("accountno",181245);
	 rs.updateString("holdername","lakshmi");
	 rs.updateString("bankname","hdfc");
	 rs.updateString("ifsccode"," hdfc8000");
	 rs.updateString("accounttype","salary");
	 rs.updateString("transcation","debit");
	 rs.updateDouble("amount",70000);
	 rs.insertRow();
	 rs.setCommand("select *  from bank");
	 rs.execute();
	 while(rs.next())
	 {
		 System.out.println(rs.getLong(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+" "+rs.getDouble(7));
	 }
	 System.out.println("inserted sucessfully");
	 System.out.println("----delete last row-------");
	 rs.last();
     rs.deleteRow(); 
     rs.setCommand("select *  from bank");
	 rs.execute();
	 while(rs.next())
	 {
		 System.out.println(rs.getLong(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+" "+rs.getDouble(7));
	 }
     System.out.println("deleted sucessfully");
     System.out.println("----delete first row-------");
	 rs.first();
     rs.deleteRow(); 
     rs.setCommand("select *  from bank");
	 rs.execute();
	 while(rs.next())
	 {
		 System.out.println(rs.getLong(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+" "+rs.getDouble(7));
	 }
     System.out.println("deleted sucessfully");
	 
	 rs.close();
	

	
}

}