package jdbc;

import java.sql.SQLException;

import javax.sql.rowset.JdbcRowSet;
import javax.sql.rowset.RowSetProvider;

public class RowSetEx {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		JdbcRowSet rowset=RowSetProvider.newFactory().createJdbcRowSet();
		String url="jdbc:mysql://localhost:3306/seethadb";
		String username="seetha";
		String password="seetharamesh";
		
		rowset.setUrl(url);
		rowset.setUsername(username);
		rowset.setPassword(password);
		
		rowset.setCommand("select * from student");
		rowset.execute();
		
		while(rowset.next())
		{
			System.out.println(rowset.getInt(1)+" "+rowset.getString(2)+" "+rowset.getString(3)+" "+rowset.getLong(4));
		}
		
		
		System.out.println();
		rowset.setCommand("select * from trainer");
		rowset.execute();
		
		while(rowset.next())
		{
			System.out.println(rowset.getInt(1)+" "+rowset.getString(2)+" "+rowset.getString(3)+" "+rowset.getInt(4)+" "+rowset.getString(5));
		}
	}

}
