package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class TransactionManagementEx {
static Connection con=null;

	public PreparedStatement getPreparedStatement1() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/seethadb";
		String username="seetha";
		String password = "seetharamesh";
		con = DriverManager.getConnection(url,username,password);
		con.setAutoCommit(false);
		String sql="insert into student values(?,?,?,?)";
		PreparedStatement ps= con.prepareStatement(sql);
		return ps;
	}
	
	public Statement getStatement1() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/seethadb";
		String username="seetha";
		String password = "seetharamesh";
		con = DriverManager.getConnection(url,username,password);
		con.setAutoCommit(false);
		
		Statement ps= con.createStatement();
		return ps;
	}
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		TransactionManagementEx tm=new TransactionManagementEx();
		PreparedStatement ps=tm.getPreparedStatement1();
		
		ps.setInt(1, 666);
		ps.setString(2,"udai");
		ps.setString(3, "uk");
		ps.setLong(4, 97854212);		
		
		
		PreparedStatement ps1=tm.getPreparedStatement1();
		
		ps1.setInt(1, 343);
		ps1.setString(2,"paritha");
		ps1.setString(3, "mp");
		ps1.setLong(4, 98425178);		
		ps1.execute();
		ps.execute();
		con.commit();
		
		
		
		TransactionManagementEx tm1=new TransactionManagementEx();
		
		Statement st=tm1.getStatement1();
		int i=st.executeUpdate("insert into student values(122,'vicky','gujarat',98974521)");		
		int j=st.executeUpdate("insert into student values(121,'maha','delhi',82451278)");
		con.commit();
		
		System.out.println("data inserted");
		
		

	}

}
