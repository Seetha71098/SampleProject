package jdbc;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnectionEx {

	public static void main(String[] args) throws SQLException {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/seethadb";
			String username = "seetha";
			String password = "seetharamesh";
		    Connection con = DriverManager.getConnection(url,username,password);
		    Statement st=con.createStatement();
		    String sql="select * from student";
		    ResultSet rs=st.executeQuery(sql);
		    
		    while(rs.next())
		    {
		    	System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getLong(4));
		    }
		    
		    System.out.println();
		    ResultSetMetaData rsmd =rs.getMetaData();
		    
		    System.out.println(rsmd.getColumnCount());
		    System.out.println(rsmd.getColumnName(1));
		    System.out.println(rsmd.getColumnName(2));
		    
		    System.out.println(rsmd.getColumnType(1));
		    
		    DatabaseMetaData dbmd=con.getMetaData();
		    
		    System.out.println(dbmd.getDriverName());
		    
//		    ResultSet rs2=dbmd.getSchemas();
//		    while(rs2.next())
//		    {
//		      System.out.println(rs2.getString(2));
//		    }
		    
		    
		    System.out.println();
		    String sql1="select * from sample";
		    ResultSet rs1=st.executeQuery(sql1);
		   
		    while(rs1.next())
		    {
		    	System.out.println(rs1.getInt(1)+" "+rs1.getString(2)+" "+rs1.getInt(3));
		    }
		    
		    rs.close();
		    rs1.close();
		    st.close();
		    con.close();
		} 
		
		
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
