package jdbc;

public class Trainer {
	
	private int trainerId;
	private String trainerFname;
	private String trainerLname;
	private int noofexp;
	private String trainerSpecialization;
	
	@Override
	public String toString() {
		return "Trainer [trainerId=" + trainerId + ", trainerFname=" + trainerFname + ", trainerLname=" + trainerLname
				+ ", noofexp=" + noofexp + ", trainerSpecialization=" + trainerSpecialization + "]";
	}

	public Trainer() {
		
	}

	public Trainer(int trainerId, String trainerFname, String trainerLname, int noofexp, String trainerSpecialization) {
		super();
		this.trainerId = trainerId;
		this.trainerFname = trainerFname;
		this.trainerLname = trainerLname;
		this.noofexp = noofexp;
		this.trainerSpecialization = trainerSpecialization;
	}

	public int getTrainerId() {
		return trainerId;
	}

	public void setTrainerId(int trainerId) {
		this.trainerId = trainerId;
	}

	public String getTrainerFname() {
		return trainerFname;
	}

	public void setTrainerFname(String trainerFname) {
		this.trainerFname = trainerFname;
	}

	public String getTrainerLname() {
		return trainerLname;
	}

	public void setTrainerLname(String trainerLname) {
		this.trainerLname = trainerLname;
	}

	public int getNoofexp() {
		return noofexp;
	}

	public void setNoofexp(int noofexp) {
		this.noofexp = noofexp;
	}

	public String getTrainerSpecialization() {
		return trainerSpecialization;
	}

	public void setTrainerSpecialization(String trainerSpecialization) {
		this.trainerSpecialization = trainerSpecialization;
	}
	
	
	
	

}
