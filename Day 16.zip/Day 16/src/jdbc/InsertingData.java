package jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class InsertingData {

	public static void main(String[] args) throws SQLException {
		
		Scanner scan=new Scanner(System.in);
		char c='Y';
		do {
			
			Trainer t1=new Trainer();
			System.out.println("enter first name:");
			String fname=scan.next();
			System.out.println("enter last name:");
			String lname=scan.next();
			System.out.println("enter experince:");
			int exp=scan.nextInt();
			System.out.println("enter specialization:");
			String specialization=scan.next();

			
			t1.setTrainerFname(fname);
			t1.setTrainerLname(lname);
			t1.setNoofexp(exp);
			t1.setTrainerSpecialization(specialization);
			
			Connection con=null;
			PreparedStatement ps=null;
			Statement st=null;
			ResultSet rs = null;

			try {
				
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/seethadb";
				String username = "seetha";
				String password = "seetharamesh";
			    con = DriverManager.getConnection(url,username,password);
				
			    String sql="insert into trainer(tfname,tlname,texp,tspecialization)values(?,?,?,?)";
			    ps=con.prepareStatement(sql);
			    ps.setString(1,t1.getTrainerFname());
			    ps.setString(2,t1.getTrainerLname());
			    ps.setInt(3,t1.getNoofexp());
			    ps.setString(4,t1.getTrainerSpecialization());
			    
			    ps.execute();
			    System.out.println("entered data successfully");
			    
				st=con.createStatement();
				String sql1="select * from trainer";
				rs=st.executeQuery(sql1);
				while(rs.next())
				{
					System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getInt(4));
				}

				System.out.println("do you want to update and delete y/n");
				char ch=scan.next().charAt(0);
				while(ch=='y')
				{
					
					 String sql2 = "UPDATE trainer SET texp = 15 WHERE tid=3 ";
					 st.executeUpdate(sql2);
					 
					 String sql3 = "delete from trainer WHERE tid=4 ";
					 st.executeUpdate(sql3);
					 
//					 System.out.println("do you want to continue insert update y/n");
//						ch=scan.next().charAt(0);
				}
				
	} 

			   catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			finally {
				ps.close();
				con.close();
				rs.close();
			}
			System.out.println("do you want to continue Y/N");
			c=scan.next().charAt(0);

	}while(c!='N');

	}

}
