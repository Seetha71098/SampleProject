package task;

public class AllException {

	

	public int Arithmetic(int a,int b)
	{
		return a/b;
	}
}