package task;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.Test;

class EvenPrimeArmstrongTest {
	Number nx=new Number();
	
	 @Test
	   public void testIsPrime() {
	      
	      assertTrue("17 is a prime number",
	                 nx.isPrime(new Integer(17)));
	      assertFalse("16 is not a prime number",
	                  nx.isPrime(new Integer(16)));
	   } 

	 @Test
	    public void testEvenOddNumber(){
	      
	        assertEquals("10 is a even number", true, nx.isEvenNumber(10));
	    }


	 @Test
	    public void testisAmstrong() {
	      assertEquals(nx.isAmstrong(153), equals(true));
	    }
}
