package task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class AllExceptionTest {


	 AllException ae=new AllException();
	@Test
	 public void testisArithmetic() {
		assertEquals(3, ae.Arithmetic(6, 2),"successfuly");
	
	}

}
