package day13;

import org.apache.log4j.Logger;

public class SomeLogEx {
	private static Logger log=Logger.getLogger(SomeLogEx.class);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SomeLogEx sl=new SomeLogEx();
	     sl.display();
	     sl.add(12,12);
	     sl.division(4,0);
	   }
	  public void display() {
		  System.out.println("this is display method");
		  log.debug("completed display");
	  }
	  public void division(int a,int b) {
		  try {
			  System.out.println("division:" +(a/b));
	      }
		  catch(Exception e) {
			  e.printStackTrace();
			  log.error("number divided by zero");
		  }
	  }
	  public void add(int a,int b) {
		  System.out.println("addition:" +(a+b));
		  log.debug("done on add");
	  }
	}

