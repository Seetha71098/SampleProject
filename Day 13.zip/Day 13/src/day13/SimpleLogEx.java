package day13;

import java.io.IOException;

import org.apache.log4j.Appender;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.HTMLLayout;
import org.apache.log4j.Layout;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.SimpleLayout;
import org.apache.log4j.xml.XMLLayout;

public class SimpleLogEx {
private static Logger log=Logger.getLogger(SimpleLogEx.class);
private static Layout layout=new SimpleLayout();
private static Appender app=new ConsoleAppender(layout);

private static Layout layout1=new PatternLayout("{%C} - %d{YY-MM-DD hh:mm} - %m - {%F} %n");
private static Layout layout2=new HTMLLayout();
private static Layout layout3=new XMLLayout();

	public static void main(String[] args) throws IOException {
		Appender fapp=new FileAppender(layout1,"logging.txt");
		Appender happ=new FileAppender(layout2,"sample.html");
		Appender xapp=new FileAppender(layout3,"demo.xml");

     log.addAppender(app);
     log.addAppender(fapp);
     log.addAppender(happ);
     log.addAppender(xapp);
     SimpleLogEx sl=new SimpleLogEx();
     sl.display();
     sl.add(12,12);
     sl.division(4,0);
   }
  public void display() {
	  System.out.println("this is display method");
	  log.debug("completed display");
  }
  public void division(int a,int b) {
	  try {
		  System.out.println("division:" +(a/b));
      }
	  catch(Exception e) {
		  e.printStackTrace();
		  log.error("number divided by zero");
	  }
  }
  public void add(int a,int b) {
	  System.out.println("addition:" +(a+b));
	  log.debug("done on add");
  }
}
