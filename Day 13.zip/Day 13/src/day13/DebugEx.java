package day13;

public class DebugEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 DebugEx de=new DebugEx();
 de.display();
 de.add(53,45);
	}
public void display() {
	System.out.println("this is display method");
}
public void add(int a,int b) {
	System.out.println("addition:" +(a+b));
}
}
