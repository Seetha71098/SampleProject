package junit;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class MathEqTest {

	MathEq e=new MathEq();
	@Test
	void testAdd() {
		
		assertEquals(12,e.add(6, 6),"wrong in add method");
		
	}

	@Test
	void testSub() {
		
		assertEquals(0,e.sub(6, 6),"wrong in sub method");
	}
	
	@Test
	void testMul() {
		
		assertEquals(36,e.mul(6, 6),"wrong in mul method");
	}
	

	@Test
	void testSortArray() {MathEq e=new MathEq();
		int a[]= {56,9,7,90,0,-4};
		int expected[]= {-4,0,7,9,56,90};
		assertArrayEquals(expected,e.sortArray(a),"wrong in sorting method");
	}
	
	@Test
	void testDivision() {
		
	//	assertThrows()
	}
}