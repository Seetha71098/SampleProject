package junit;

public class MathEq {
public int add(int a,int b) {
	return a+b;
}
public int sub(int a,int b) {
     return a-b;
}
public int mul(int a,int b) {
      return a*b;
}
public int div(int a,int b) {
      return a/b;
}

public int[] sortArray(int...arr) {
	int tmp;
	for(int i=0;i<arr.length;i++) {
		for(int j=i+1;j<arr.length;j++) {
			int temp=0;
			if(arr[i]>arr[j]) {
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
	}
	return arr;
	}
}
